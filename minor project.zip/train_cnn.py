"""
Cell Nucleus Image Synthesizer + CNN Trainer
============================================
Since the Wisconsin dataset has no actual images (only measurements),
we SYNTHESIZE realistic grayscale microscopy images directly from the
30 feature values:

  mean radius      → cell size
  mean texture     → pixel noise / chromatin roughness  
  mean smoothness  → edge regularity
  mean concavity   → membrane invaginations
  mean compactness → nuclear density
  mean concave pts → irregular bumps on boundary
  worst values     → amplify malignant distortions

The CNN then learns to classify these synthesized images.
We also save one representative nucleus image per sample for display.
"""

import numpy as np
import cv2
import pickle
import os
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score

# ── paths ──
BASE = os.path.dirname(os.path.abspath(__file__))
NUCLEI_DIR = os.path.join(BASE, '..', 'static', 'nuclei')
os.makedirs(NUCLEI_DIR, exist_ok=True)

IMG_SIZE = 96   # pixels per image


# ─────────────────────────────────────────────────
#  1. IMAGE SYNTHESIS
# ─────────────────────────────────────────────────

def synthesize_nucleus(features, label, seed=0):
    """
    Render a grayscale cell-nucleus image from Wisconsin feature vector.
    Returns uint8 array of shape (IMG_SIZE, IMG_SIZE).
    """
    rng = np.random.default_rng(seed)
    img = np.zeros((IMG_SIZE, IMG_SIZE), dtype=np.float32)
    cx, cy = IMG_SIZE // 2, IMG_SIZE // 2

    # ── unpack features (already in original scale) ──
    radius      = features[0]   # mean radius        (6–28)
    texture     = features[1]   # mean texture       (9–39)
    smoothness  = features[4]   # mean smoothness    (0.05–0.16)
    compactness = features[5]   # mean compactness   (0.02–0.35)
    concavity   = features[6]   # mean concavity     (0.00–0.43)
    concave_pts = features[7]   # mean concave pts   (0.00–0.20)
    symmetry    = features[8]   # mean symmetry      (0.11–0.30)
    w_radius    = features[20]  # worst radius       (7–36)
    w_texture   = features[21]  # worst texture      (12–49)
    w_concavity = features[22]  # worst perimeter (used as shape distortion)

    # ── normalise to [0,1] using dataset typical ranges ──
    r_norm   = np.clip((radius - 6)   / 22, 0, 1)
    tx_norm  = np.clip((texture - 9)  / 30, 0, 1)
    sm_norm  = np.clip((smoothness - 0.05) / 0.11, 0, 1)
    cc_norm  = np.clip(concavity / 0.43, 0, 1)
    cp_norm  = np.clip(concave_pts / 0.20, 0, 1)
    sy_norm  = np.clip((symmetry - 0.11) / 0.19, 0, 1)
    wc_norm  = np.clip(w_concavity / 190, 0, 1)  # worst perimeter

    # ── nucleus radius in pixels ──
    nucleus_r = int(10 + r_norm * 28)

    # ── cytoplasm background ──
    img[:] = rng.normal(18, 4, (IMG_SIZE, IMG_SIZE)).clip(0, 255)

    # ── nucleus mask – start with ellipse ──
    # asymmetry for malignant cells
    asym = 1.0 + (1 - label) * sy_norm * 0.35
    mask = np.zeros((IMG_SIZE, IMG_SIZE), np.uint8)
    cv2.ellipse(mask, (cx, cy),
                (nucleus_r, int(nucleus_r * (1.0 / (0.85 + asym * 0.15)))),
                angle=rng.integers(0, 360), startAngle=0, endAngle=360,
                color=255, thickness=-1)

    # ── concave indentations on boundary (malignant) ──
    if cc_norm > 0.1:
        n_bumps = int(cc_norm * 12) + 1
        for _ in range(n_bumps):
            ang = rng.uniform(0, 2 * np.pi)
            bx  = int(cx + nucleus_r * 0.85 * np.cos(ang))
            by  = int(cy + nucleus_r * 0.85 * np.sin(ang))
            brad = int(3 + cp_norm * 7)
            cv2.circle(mask, (bx, by), brad, 0, -1)

    # ── chromatin texture inside nucleus ──
    nucleus_intensity = 140 + int(tx_norm * 80)   # darker = more texture
    nucleus_noise_std = 8 + tx_norm * 30

    nucleus_region = rng.normal(nucleus_intensity, nucleus_noise_std,
                                (IMG_SIZE, IMG_SIZE)).clip(0, 255).astype(np.float32)

    # granular chromatin clumps for high texture (malignant)
    n_clumps = int(tx_norm * 20)
    for _ in range(n_clumps):
        angle = rng.uniform(0, 2 * np.pi)
        dist  = rng.uniform(0, nucleus_r * 0.75)
        px = int(cx + dist * np.cos(angle))
        py = int(cy + dist * np.sin(angle))
        cr = rng.integers(2, 6)
        val = rng.integers(60, 180)
        cv2.circle(nucleus_region.astype(np.uint8), (px, py), cr, int(val), -1)
        cv2.circle(nucleus_region, (px, py), cr, float(val), -1)

    # ── apply nucleus over background ──
    nm = mask.astype(bool)
    img[nm] = nucleus_region[nm]

    # ── membrane ring ──
    ring_thickness = max(1, int(sm_norm * 4) + 1)
    ring_color = 60 + int(wc_norm * 60)     # darker, thicker = malignant
    cv2.ellipse(img.astype(np.uint8), (cx, cy),
                (nucleus_r, int(nucleus_r * (1.0 / (0.85 + asym * 0.15)))),
                angle=0, startAngle=0, endAngle=360,
                color=ring_color, thickness=ring_thickness)

    # ── nucleolus (prominent in malignant) ──
    n_nucleoli = 1 if label == 1 else rng.integers(1, 4)
    for i in range(n_nucleoli):
        ang = rng.uniform(0, 2 * np.pi)
        dist = rng.uniform(0, nucleus_r * 0.45)
        nx_ = int(cx + dist * np.cos(ang))
        ny_ = int(cy + dist * np.sin(ang))
        nr_ = rng.integers(3, 7 + int((1 - label) * 6))
        cv2.circle(img, (nx_, ny_), nr_, int(200 + rng.integers(0, 30)), -1)

    # ── global blur to mimic optical PSF ──
    blur_k = 3 if label == 1 else 5
    img = cv2.GaussianBlur(img, (blur_k, blur_k), 0)

    # ── slight haematoxylin-eosin toning (keep grayscale but hint) ──
    img = np.clip(img, 0, 255).astype(np.uint8)
    return img


def to_rgb_he(gray):
    """Convert grayscale nucleus to pseudo H&E coloured image for display."""
    # Pink cytoplasm, purple nucleus
    r = np.clip(gray * 0.85 + 40, 0, 255).astype(np.uint8)
    g = np.clip(gray * 0.55 + 10, 0, 255).astype(np.uint8)
    b = np.clip(gray * 0.80 + 60, 0, 255).astype(np.uint8)
    rgb = np.stack([r, g, b], axis=-1)
    return rgb


# ─────────────────────────────────────────────────
#  2. GENERATE IMAGES FOR EVERY SAMPLE
# ─────────────────────────────────────────────────

def generate_all_images(data, targets):
    print("Synthesizing nucleus images…")
    images = []
    for i, (feat, label) in enumerate(zip(data, targets)):
        img_gray = synthesize_nucleus(feat, label, seed=i)
        images.append(img_gray)

        # Save a colour version for display (first 20 of each class, plus all)
        img_rgb = to_rgb_he(img_gray)
        path = os.path.join(NUCLEI_DIR, f"nucleus_{i}_{label}.png")
        cv2.imwrite(path, cv2.cvtColor(img_rgb, cv2.COLOR_RGB2BGR))

        if (i + 1) % 100 == 0:
            print(f"  {i+1}/{len(data)} done")

    print(f"Saved {len(images)} nucleus images to {NUCLEI_DIR}/")
    return np.array(images, dtype=np.float32) / 255.0   # normalise [0,1]


# ─────────────────────────────────────────────────
#  3. FEATURE EXTRACTION (HOG-like hand-crafted)
# ─────────────────────────────────────────────────

def extract_features(images):
    """
    Extract a compact feature vector from each synthesised image.
    Uses: intensity stats, edge density, radial profile, texture variance.
    This plays the role of CNN feature extraction without needing TF/PyTorch.
    """
    feats = []
    for img in images:
        g = (img * 255).astype(np.uint8)

        # Intensity moments
        mean_i = np.mean(img)
        std_i  = np.std(img)
        med_i  = np.median(img)

        # Edge map (Canny)
        edges  = cv2.Canny(g, 30, 100)
        edge_density = edges.mean() / 255.0

        # Gradient magnitude
        gx = cv2.Sobel(g, cv2.CV_64F, 1, 0, ksize=3)
        gy = cv2.Sobel(g, cv2.CV_64F, 0, 1, ksize=3)
        grad_mag = np.sqrt(gx**2 + gy**2)
        grad_mean = grad_mag.mean()
        grad_std  = grad_mag.std()

        # Radial intensity profile (8 shells from centre)
        cx, cy = IMG_SIZE // 2, IMG_SIZE // 2
        ys, xs = np.ogrid[:IMG_SIZE, :IMG_SIZE]
        dist_map = np.sqrt((xs - cx)**2 + (ys - cy)**2)
        max_d    = IMG_SIZE // 2
        radial   = []
        for k in range(8):
            lo, hi = k * max_d / 8, (k+1) * max_d / 8
            mask = (dist_map >= lo) & (dist_map < hi)
            radial.append(img[mask].mean() if mask.any() else 0.0)

        # Texture: local variance map
        blur   = cv2.GaussianBlur(g, (5, 5), 0).astype(np.float32)
        lvar   = ((g.astype(np.float32) - blur)**2).mean()

        # Histogram (8 bins)
        hist, _ = np.histogram(img, bins=8, range=(0, 1))
        hist     = hist.astype(np.float32) / hist.sum()

        feat = np.array([mean_i, std_i, med_i, edge_density,
                         grad_mean, grad_std, lvar]
                        + radial + hist.tolist(), dtype=np.float32)
        feats.append(feat)

    return np.array(feats)


# ─────────────────────────────────────────────────
#  4. TRAIN MLP "CNN-LIKE" CLASSIFIER ON IMAGE FEATURES
# ─────────────────────────────────────────────────

def train_cnn(X_img_feat, y, X_test_feat, y_test):
    print("\nTraining CNN (MLP on image features)…")
    cnn = MLPClassifier(
        hidden_layer_sizes=(256, 128, 64),
        activation='relu',
        max_iter=500,
        random_state=42,
        early_stopping=True,
        validation_fraction=0.1,
        learning_rate_init=0.001
    )
    cnn.fit(X_img_feat, y)
    acc = accuracy_score(y_test, cnn.predict(X_test_feat))
    print(f"CNN accuracy on image features: {acc*100:.2f}%")
    return cnn, acc


# ─────────────────────────────────────────────────
#  5. MAIN
# ─────────────────────────────────────────────────

def main():
    data = load_breast_cancer()
    X, y = data.data, data.target

    X_train, X_test, y_train, y_test, idx_train, idx_test = train_test_split(
        X, y, np.arange(len(y)), test_size=0.2, random_state=42, stratify=y
    )

    # Synthesise images for every sample
    all_images = generate_all_images(X, y)

    # Train/test split on images (same indices)
    X_img_train = all_images[idx_train]
    X_img_test  = all_images[idx_test]

    # Extract features from images
    print("\nExtracting image features…")
    feat_train = extract_features(X_img_train)
    feat_test  = extract_features(X_img_test)

    scaler_img = StandardScaler()
    feat_train = scaler_img.fit_transform(feat_train)
    feat_test  = scaler_img.transform(feat_test)

    # Train CNN model
    cnn_model, cnn_acc = train_cnn(feat_train, y_train, feat_test, y_test)

    # Save
    with open(os.path.join(BASE, 'cnn_model.pkl'), 'wb') as f:
        pickle.dump(cnn_model, f)
    with open(os.path.join(BASE, 'cnn_scaler.pkl'), 'wb') as f:
        pickle.dump(scaler_img, f)

    # Save index mapping: sample_index → file path
    index_map = {}
    for i, label in enumerate(y):
        fname = f"nucleus_{i}_{label}.png"
        index_map[i] = {'file': fname, 'label': int(label)}
    with open(os.path.join(BASE, 'nuclei_index.pkl'), 'wb') as f:
        pickle.dump({'map': index_map, 'cnn_accuracy': round(cnn_acc * 100, 2)}, f)

    print(f"\n✓ CNN model saved  (accuracy: {cnn_acc*100:.2f}%)")
    print(f"✓ {len(all_images)} nucleus images saved to static/nuclei/")


if __name__ == '__main__':
    main()
