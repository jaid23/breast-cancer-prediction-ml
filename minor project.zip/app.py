"""
Breast Cancer Prediction - Flask Backend v3
  - ML feature-based prediction (4 models)
  - CNN image-based prediction (MLP on synthesised nucleus images)
  - Nucleus image display alongside prediction results
"""

from flask import Flask, request, jsonify, render_template
import numpy as np
import pickle
import os
import cv2
import json
import urllib.request
import base64

app = Flask(__name__)

BASE_DIR   = os.path.join(os.path.dirname(os.path.abspath(__file__)), "model")
NUCLEI_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "nuclei")

with open(os.path.join(BASE_DIR, "scaler.pkl"), "rb") as f:
    scaler = pickle.load(f)
with open(os.path.join(BASE_DIR, "best_model.pkl"), "rb") as f:
    best_model = pickle.load(f)
with open(os.path.join(BASE_DIR, "all_models.pkl"), "rb") as f:
    all_models = pickle.load(f)
with open(os.path.join(BASE_DIR, "meta.pkl"), "rb") as f:
    meta = pickle.load(f)
with open(os.path.join(BASE_DIR, "cnn_model.pkl"), "rb") as f:
    cnn_model = pickle.load(f)
with open(os.path.join(BASE_DIR, "cnn_scaler.pkl"), "rb") as f:
    cnn_scaler = pickle.load(f)
with open(os.path.join(BASE_DIR, "nuclei_index.pkl"), "rb") as f:
    nuclei_meta = pickle.load(f)

FEATURE_NAMES    = meta["feature_names"]
MODEL_ACCURACIES = meta["model_accuracies"]
BEST_MODEL_NAME  = meta["best_model_name"]
CNN_ACCURACY     = nuclei_meta["cnn_accuracy"]
NUCLEI_INDEX     = nuclei_meta["map"]
IMG_SIZE         = 96


def extract_image_features(img_gray_uint8):
    img = img_gray_uint8.astype(np.float32) / 255.0
    g   = img_gray_uint8
    mean_i       = float(np.mean(img))
    std_i        = float(np.std(img))
    med_i        = float(np.median(img))
    edges        = cv2.Canny(g, 30, 100)
    edge_density = float(edges.mean() / 255.0)
    gx       = cv2.Sobel(g, cv2.CV_64F, 1, 0, ksize=3)
    gy       = cv2.Sobel(g, cv2.CV_64F, 0, 1, ksize=3)
    grad_mag = np.sqrt(gx**2 + gy**2)
    grad_mean = float(grad_mag.mean()); grad_std = float(grad_mag.std())
    cx, cy   = IMG_SIZE // 2, IMG_SIZE // 2
    ys, xs   = np.ogrid[:IMG_SIZE, :IMG_SIZE]
    dist_map = np.sqrt((xs - cx)**2 + (ys - cy)**2)
    max_d    = IMG_SIZE // 2
    radial   = [float(img[(dist_map >= k*max_d/8) & (dist_map < (k+1)*max_d/8)].mean()) if ((dist_map >= k*max_d/8) & (dist_map < (k+1)*max_d/8)).any() else 0.0 for k in range(8)]
    blur = cv2.GaussianBlur(g, (5, 5), 0).astype(np.float32)
    lvar = float(((g.astype(np.float32) - blur)**2).mean())
    hist, _ = np.histogram(img, bins=8, range=(0, 1))
    hist     = hist.astype(np.float32) / hist.sum()
    return np.array([mean_i, std_i, med_i, edge_density, grad_mean, grad_std, lvar] + radial + hist.tolist(), dtype=np.float32)


def synthesize_nucleus(features, label, seed=999):
    rng = np.random.default_rng(seed)
    img = np.zeros((IMG_SIZE, IMG_SIZE), dtype=np.float32)
    cx, cy = IMG_SIZE // 2, IMG_SIZE // 2
    radius=features[0]; texture=features[1]; smoothness=features[4]
    concavity=features[6]; concave_pts=features[7]; symmetry=features[8]; w_concavity=features[22]
    r_norm  = np.clip((radius-6)/22,0,1); tx_norm=np.clip((texture-9)/30,0,1)
    sm_norm = np.clip((smoothness-0.05)/0.11,0,1); cc_norm=np.clip(concavity/0.43,0,1)
    cp_norm = np.clip(concave_pts/0.20,0,1); sy_norm=np.clip((symmetry-0.11)/0.19,0,1)
    wc_norm = np.clip(w_concavity/190,0,1)
    nucleus_r = int(10 + r_norm * 28)
    img[:] = rng.normal(18, 4, (IMG_SIZE, IMG_SIZE)).clip(0, 255)
    asym = 1.0 + (1 - label) * sy_norm * 0.35
    mask = np.zeros((IMG_SIZE, IMG_SIZE), np.uint8)
    cv2.ellipse(mask, (cx,cy), (nucleus_r, int(nucleus_r*(1.0/(0.85+asym*0.15)))),
                angle=int(rng.integers(0,360)), startAngle=0, endAngle=360, color=255, thickness=-1)
    if cc_norm > 0.1:
        for _ in range(int(cc_norm*12)+1):
            ang=rng.uniform(0,2*np.pi); bx=int(cx+nucleus_r*0.85*np.cos(ang)); by=int(cy+nucleus_r*0.85*np.sin(ang))
            cv2.circle(mask, (bx,by), int(3+cp_norm*7), 0, -1)
    nr = rng.normal(140+int(tx_norm*80), 8+tx_norm*30, (IMG_SIZE,IMG_SIZE)).clip(0,255).astype(np.float32)
    for _ in range(int(tx_norm*20)):
        ang=rng.uniform(0,2*np.pi); dist=rng.uniform(0,nucleus_r*0.75)
        px=int(cx+dist*np.cos(ang)); py=int(cy+dist*np.sin(ang))
        cv2.circle(nr, (px,py), int(rng.integers(2,6)), float(rng.integers(60,180)), -1)
    nm=mask.astype(bool); img[nm]=nr[nm]
    cv2.ellipse(img.astype(np.uint8), (cx,cy), (nucleus_r, int(nucleus_r*(1.0/(0.85+asym*0.15)))),
                angle=0, startAngle=0, endAngle=360, color=int(60+wc_norm*60), thickness=max(1,int(sm_norm*4)+1))
    for _ in range(1 if label==1 else int(rng.integers(1,4))):
        ang=rng.uniform(0,2*np.pi); dist=rng.uniform(0,nucleus_r*0.45)
        cv2.circle(img, (int(cx+dist*np.cos(ang)),int(cy+dist*np.sin(ang))), int(rng.integers(3,7+int((1-label)*6))), int(200+rng.integers(0,30)), -1)
    img = cv2.GaussianBlur(img, (3 if label==1 else 5, 3 if label==1 else 5), 0)
    return np.clip(img, 0, 255).astype(np.uint8)


def gray_to_he_b64(gray):
    r = np.clip(gray.astype(np.float32)*0.85+40,0,255).astype(np.uint8)
    g = np.clip(gray.astype(np.float32)*0.55+10,0,255).astype(np.uint8)
    b = np.clip(gray.astype(np.float32)*0.80+60,0,255).astype(np.uint8)
    bgr = cv2.cvtColor(np.stack([r,g,b],axis=-1), cv2.COLOR_RGB2BGR)
    big = cv2.resize(bgr, (256,256), interpolation=cv2.INTER_CUBIC)
    _, buf = cv2.imencode('.png', big)
    return base64.b64encode(buf).decode('utf-8')


@app.route("/")
def index():
    return render_template("index.html",
                           features=FEATURE_NAMES,
                           model_accuracies=MODEL_ACCURACIES,
                           best_model=BEST_MODEL_NAME,
                           cnn_accuracy=CNN_ACCURACY)


@app.route("/predict", methods=["POST"])
def predict():
    try:
        data = request.get_json()
        features = [float(data.get(f, 0)) for f in FEATURE_NAMES]
        selected_model_name = data.get("model", BEST_MODEL_NAME)
        model = all_models.get(selected_model_name, best_model)
        fa = np.array(features).reshape(1,-1)
        fs = scaler.transform(fa)
        prediction = model.predict(fs)[0]
        try:
            proba = model.predict_proba(fs)[0]
            confidence = round(float(max(proba))*100,2)
            benign_prob = round(float(proba[1])*100,2)
            malignant_prob = round(float(proba[0])*100,2)
        except:
            confidence=95.0; benign_prob=95.0 if prediction==1 else 5.0; malignant_prob=100-benign_prob

        result = "Benign" if prediction==1 else "Malignant"

        # Synthesize nucleus image from features
        gray = synthesize_nucleus(features, int(prediction), seed=42)
        img_b64 = gray_to_he_b64(gray)

        # CNN prediction on synthesised image
        ifeat = extract_image_features(gray).reshape(1,-1)
        ifeat_s = cnn_scaler.transform(ifeat)
        cnn_pred = cnn_model.predict(ifeat_s)[0]
        cnn_proba = cnn_model.predict_proba(ifeat_s)[0]
        cnn_result = "Benign" if cnn_pred==1 else "Malignant"
        cnn_conf = round(float(max(cnn_proba))*100,2)

        # Agreement
        agreement = (result == cnn_result)

        return jsonify({
            "prediction": result, "confidence": confidence,
            "benign_probability": benign_prob, "malignant_probability": malignant_prob,
            "model_used": selected_model_name,
            "model_accuracy": MODEL_ACCURACIES.get(selected_model_name,0),
            "cnn_prediction": cnn_result, "cnn_confidence": cnn_conf,
            "cnn_accuracy": CNN_ACCURACY, "models_agree": agreement,
            "nucleus_image_b64": img_b64
        })
    except Exception as e:
        import traceback; traceback.print_exc()
        return jsonify({"error": str(e)}), 400


@app.route("/gallery")
def gallery():
    from sklearn.datasets import load_breast_cancer
    d = load_breast_cancer()
    benign_ids    = [i for i,l in enumerate(d.target) if l==1][:6]
    malignant_ids = [i for i,l in enumerate(d.target) if l==0][:6]
    items = []
    for sid in benign_ids + malignant_ids:
        info = NUCLEI_INDEX.get(sid)
        if not info: continue
        fpath = os.path.join(NUCLEI_DIR, info['file'])
        if not os.path.exists(fpath): continue
        with open(fpath,'rb') as f:
            b64 = base64.b64encode(f.read()).decode('utf-8')
        items.append({"id":sid,"label":info['label'],
                      "diagnosis":"Benign" if info['label']==1 else "Malignant",
                      "image_b64":b64})
    return jsonify({"images": items})


@app.route("/models")
def get_models():
    return jsonify({"models": MODEL_ACCURACIES, "best_model": BEST_MODEL_NAME,
                    "cnn_accuracy": CNN_ACCURACY})


@app.route("/features")
def get_features():
    return jsonify({"features": FEATURE_NAMES})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
